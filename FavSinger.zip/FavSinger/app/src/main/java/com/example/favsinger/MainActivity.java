package com.example.favsinger;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    RecyclerView rcv;
    MyAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("My Favorite Singers");
        rcv = (RecyclerView) findViewById(R.id.recview);
        adapter = new MyAdapter(dataqueue(),getApplicationContext());
        rcv.setAdapter(adapter);
        GridLayoutManager gridLayoutManager=new GridLayoutManager(this,2);
        rcv.setLayoutManager(gridLayoutManager);
    }

    public ArrayList<Model> dataqueue()
    {
        ArrayList<Model> holder=new ArrayList<>();

        Model ob1=new Model();
        ob1.setHeader("Alec Benjamin");
        ob1.setDesc("My favorite song : Water Fountain ");
        ob1.setImgname(R.drawable.alecben);
        holder.add(ob1);

        Model ob2=new Model();
        ob2.setHeader("Neoni");
        ob2.setDesc("My favorite song : Champion");
        ob2.setImgname(R.drawable.neoni);
        holder.add(ob2);

        Model ob3=new Model();
        ob3.setHeader("Nico Collins");
        ob3.setDesc("My favorite song : It Is My Bad");
        ob3.setImgname(R.drawable.nico);
        holder.add(ob3);

        Model ob4=new Model();
        ob4.setHeader("Jack Daniels");
        ob4.setDesc("My favorite song : The Show");
        ob4.setImgname(R.drawable.jack);
        holder.add(ob4);

        Model ob5=new Model();
        ob5.setHeader("Neffex");
        ob5.setDesc("My favorite song : Space.");
        ob5.setImgname(R.drawable.neffex);
        holder.add(ob5);

        Model ob6=new Model();
        ob6.setHeader("Ilira");
        ob6.setDesc("My favorite song : Pay Me Back");
        ob6.setImgname(R.drawable.ilira);
        holder.add(ob6);

        Model ob7=new Model();
        ob7.setHeader("Sasha Sloan");
        ob7.setDesc("My favorite song : Is It Just Me");
        ob7.setImgname(R.drawable.sasha);
        holder.add(ob7);

        Model ob8=new Model();
        ob8.setHeader("Arcando");
        ob8.setDesc("My favorite song : End of The World (Arcando and That Behavior feat Neoni)");
        ob8.setImgname(R.drawable.arcando);
        holder.add(ob8);

        Model ob9=new Model();
        ob9.setHeader("Kina");
        ob9.setDesc("My favorite song : Wish I Was Better");
        ob9.setImgname(R.drawable.kina);
        holder.add(ob9);

        Model ob10=new Model();
        ob10.setHeader("Besomorph");
        ob10.setDesc("My favorite song :");
        ob10.setImgname(R.drawable.besomorph);
        holder.add(ob10);

        return holder;
    }


}
